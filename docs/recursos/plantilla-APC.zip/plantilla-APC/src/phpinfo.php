<?php
    $a = 3;
    echo "prueba";
    $a++;
    
?>